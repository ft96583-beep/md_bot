NEXORA PANEL APK - Working ZIP
==============================

Is me kya hai:
- nexora-panel.apk ..... tayyar WORKING app (phone me install karo, khul jayegi)
- app/ ................ app ka poora source code
- build-apk.sh ........ dobara APK banane ki script (computer par chalti hai)

CHEZEN KAISE BADLEIN (source me):
1. App ka naam ...: app/src/main/res/values/strings.xml me "NEXORA Panel" badlo
2. Website ka link : app/src/main/java/pk/nexora/panel/MainActivity.java me
                     HOME = "https://..." wali line me apna link likho
3. Icon ...........: app/src/main/res/drawable/ic_launcher.xml

DOBARA APK KAISE BANAYEIN (computer/Linux par):
1. Java 17 aur Android SDK (build-tools 34, platform android-34) install karo
2. Terminal me is folder me jao aur chalao:
     SDK=/path/to/android-sdk JAVA_HOME=/path/to/jdk17 ./build-apk.sh
3. Nayi tayyar APK ban jayegi: nexora-panel.apk

NOTE: Agar tumhare paas computer nahi ya ye sab mushkil lage,
to fikar mat karo — mujhe bata do kya change chahiye,
main khud change karke nayi working APK de dunga. 💗
