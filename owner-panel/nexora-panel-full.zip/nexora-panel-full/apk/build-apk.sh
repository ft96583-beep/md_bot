#!/bin/bash
# Manual APK build for NEXORA Owner Panel (no Gradle needed) — same proven pattern as instasave-apk
set -e
JAVA_HOME=${JAVA_HOME:-~/workspace/jdk17}
export JAVA_HOME
export PATH=$JAVA_HOME/bin:$PATH
SDK=${SDK:-~/workspace/android-sdk}
BT=$SDK/build-tools/34.0.0
PJ=~/workspace/panel-apk
BD=/tmp/panelapkbuild

rm -rf $BD && mkdir -p $BD/gen $BD/classes $BD/dex

echo "== aapt2 compile =="
$BT/aapt2 compile --dir $PJ/app/src/main/res -o $BD/compiled_res.zip

echo "== aapt2 link =="
$BT/aapt2 link -o $BD/unsigned.apk \
  -I $SDK/platforms/android-34/android.jar \
  --manifest $PJ/app/src/main/AndroidManifest.xml \
  --java $BD/gen \
  --min-sdk-version 29 --target-sdk-version 34 \
  --version-code 1 --version-name 1.0 \
  $BD/compiled_res.zip

echo "== javac =="
$JAVA_HOME/bin/javac -source 8 -target 8 -nowarn \
  -cp $SDK/platforms/android-34/android.jar \
  -d $BD/classes \
  $(find $PJ/app/src/main/java $BD/gen -name "*.java")

echo "== d8 =="
$BT/d8 --lib $SDK/platforms/android-34/android.jar --min-api 29 \
  --output $BD/dex \
  $(find $BD/classes -name "*.class")

echo "== add dex to apk =="
cp $BD/dex/classes.dex $BD/
cd $BD && zip -q -j unsigned.apk classes.dex && cd - >/dev/null

echo "== zipalign =="
$BT/zipalign -f 4 $BD/unsigned.apk $BD/aligned.apk

echo "== sign =="
if [ ! -f $BD/debug.keystore ]; then
  $JAVA_HOME/bin/keytool -genkeypair -keystore $BD/debug.keystore \
    -alias androiddebugkey -storepass android -keypass android \
    -keyalg RSA -keysize 2040 -validity 10950 \
    -dname "CN=Android Debug,O=Android,C=US" 2>/dev/null
fi
$BT/apksigner sign --ks $BD/debug.keystore --ks-pass pass:android \
  --out $PJ/nexora-panel.apk $BD/aligned.apk

echo "== verify =="
$BT/apksigner verify --print-certs $PJ/nexora-panel.apk | head -3
ls -la $PJ/nexora-panel.apk
$BT/aapt2 dump badging $PJ/nexora-panel.apk | head -8
