NEXORA PANEL APK
================
- nexora-panel.apk ... tayyar WORKING app (install karo, chal jayegi)
- app/ ............. poora source code
- build-apk.sh ..... dobara APK banane ki script

Badalna ho to:
1. App ka naam: app/src/main/res/values/strings.xml ("NEXORA Panel")
2. Website link: app/src/main/java/pk/nexora/panel/MainActivity.java (HOME = "...")
3. Icon: app/src/main/res/drawable/ic_launcher.xml

Dobara banana (computer par):
  SDK=/path/to/android-sdk JAVA_HOME=/path/to/jdk17 ./build-apk.sh
